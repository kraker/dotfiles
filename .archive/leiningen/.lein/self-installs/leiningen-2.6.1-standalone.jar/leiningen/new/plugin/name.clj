(ns leiningen.{{unprefixed-name}})

(defn {{unprefixed-name}}
  "I don't do a lot."
  [project & args]
  (println "Hi!"))
